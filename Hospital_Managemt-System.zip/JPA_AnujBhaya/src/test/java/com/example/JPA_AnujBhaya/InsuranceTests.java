package com.example.JPA_AnujBhaya;

import com.example.JPA_AnujBhaya.entity.Insurance;
import com.example.JPA_AnujBhaya.entity.Patient;
import com.example.JPA_AnujBhaya.service.InsurenceService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDate;
import java.time.LocalDateTime;

@SpringBootTest
public class InsuranceTests {

    @Autowired
    private InsurenceService insurenceService;

    @Test
    public void testInsurance(){

        Insurance insurance= Insurance.builder()
                .policyNumber("HDFC_1234")
                .provider("HBL")
                .validUntil(LocalDate.from(LocalDate.of(2030,12,12)).atStartOfDay())
                .build();

        Patient patient = insurenceService.assignInsuranceToPatient(insurance,1L);
        System.out.println(patient);


        var newPatient = insurenceService.disAssociateInsuranceFromPatient(patient.getId());
        System.out.println(newPatient);

    }
}
