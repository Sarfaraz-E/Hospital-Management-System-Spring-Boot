package com.example.JPA_AnujBhaya.service;

import com.example.JPA_AnujBhaya.entity.Insurance;
import com.example.JPA_AnujBhaya.entity.Patient;
import com.example.JPA_AnujBhaya.repository.InsuranceRepository;
import com.example.JPA_AnujBhaya.repository.PatientRepository;
import jakarta.persistence.EntityNotFoundException;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class InsurenceService {

    private final InsuranceRepository insurenceRepository;  //Final Due to Required ArgsConstructor
    private final PatientRepository patientRepository;


    @Transactional //If all steps will run elase no output will work
    public Patient assignInsuranceToPatient(Insurance insurance,Long patientId){
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new EntityNotFoundException("Patient Not Found with id:" + patientId));

        patient.setInsurance(insurance);

        insurance.setPatient(patient); //for bidirectinal consistency maintenence


        return patient;
    }


    @Transactional
    public Patient disAssociateInsuranceFromPatient(Long patientId){
        Patient patient = patientRepository.findById(patientId)
                .orElseThrow(() -> new EntityNotFoundException("Patient not found with id:" + patientId));
        patient.setInsurance(null); //Here patient will dirty so

        return patient;
    }

}
