package com.example.JPA_AnujBhaya.repository;

import com.example.JPA_AnujBhaya.entity.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<Appointment,Long> {
}
