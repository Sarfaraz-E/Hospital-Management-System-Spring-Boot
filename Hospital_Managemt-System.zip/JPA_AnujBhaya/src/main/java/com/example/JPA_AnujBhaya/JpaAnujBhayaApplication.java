package com.example.JPA_AnujBhaya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaAnujBhayaApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaAnujBhayaApplication.class, args);
	}

}
