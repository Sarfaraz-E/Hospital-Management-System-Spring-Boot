package com.example.JPA_AnujBhaya.repository;

import com.example.JPA_AnujBhaya.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department,Long> {
}
