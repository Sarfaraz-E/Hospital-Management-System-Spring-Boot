package com.example.JPA_AnujBhaya.repository;

import com.example.JPA_AnujBhaya.entity.Insurance;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InsuranceRepository extends JpaRepository<Insurance, Long> {
}
