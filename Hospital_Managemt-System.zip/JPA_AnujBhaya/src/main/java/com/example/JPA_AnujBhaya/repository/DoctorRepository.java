package com.example.JPA_AnujBhaya.repository;

import com.example.JPA_AnujBhaya.entity.Doctor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DoctorRepository extends JpaRepository<Doctor,Long> {
}
